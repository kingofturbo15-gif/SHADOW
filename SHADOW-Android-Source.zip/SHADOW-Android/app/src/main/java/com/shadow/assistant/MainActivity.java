package com.shadow.assistant;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private TextView status, transcript;
    private TextToSpeech tts;
    private SpeechRecognizer recognizer;
    private static final int MIC_REQUEST = 44;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(Color.rgb(5, 10, 20));
        getWindow().setNavigationBarColor(Color.rgb(5, 10, 20));

        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER);
        page.setPadding(28, 40, 28, 40);
        page.setBackgroundColor(Color.rgb(5, 10, 20));

        TextView title = new TextView(this);
        title.setText("S H A D O W");
        title.setTextColor(Color.rgb(0, 220, 255));
        title.setTextSize(30);
        title.setGravity(Gravity.CENTER);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("YOUR PERSONAL VOICE ASSISTANT");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(12);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = matchWrap();
        sp.topMargin = 10;
        page.addView(subtitle, sp);

        status = new TextView(this);
        status.setText("SYSTEM ONLINE  •  STANDBY");
        status.setTextColor(Color.rgb(0, 220, 160));
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stp = matchWrap();
        stp.topMargin = 55;
        page.addView(status, stp);

        Button listen = new Button(this);
        listen.setText("TAP TO SPEAK");
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
        bp.topMargin = 35;
        page.addView(listen, bp);

        transcript = new TextView(this);
        transcript.setText("Say: “open YouTube”, “search for …”, or “what time is it?”");
        transcript.setTextColor(Color.WHITE);
        transcript.setTextSize(16);
        transcript.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tp = matchWrap();
        tp.topMargin = 30;
        page.addView(transcript, tp);

        TextView note = new TextView(this);
        note.setText("SHADOW v1.0  |  Voice recognition needs internet or an installed speech service.");
        note.setTextColor(Color.GRAY);
        note.setTextSize(11);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = matchWrap();
        np.topMargin = 55;
        page.addView(note, np);

        setContentView(page);

        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) tts.setLanguage(Locale.getDefault());
        });

        listen.setOnClickListener(v -> startListening());
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private void startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.setText("NO SPEECH RECOGNITION SERVICE");
            speak("Speech recognition is not available on this phone.");
            return;
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, MIC_REQUEST);
            return;
        }
        if (recognizer != null) recognizer.destroy();
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new android.speech.RecognitionListener() {
            public void onReadyForSpeech(Bundle b) { status.setText("LISTENING..."); }
            public void onBeginningOfSpeech() {}
            public void onRmsChanged(float r) {}
            public void onBufferReceived(byte[] b) {}
            public void onEndOfSpeech() { status.setText("PROCESSING..."); }
            public void onError(int e) { status.setText("TRY AGAIN"); }
            public void onResults(Bundle b) {
                ArrayList<String> matches = b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (matches != null && !matches.isEmpty()) handleCommand(matches.get(0));
            }
            public void onPartialResults(Bundle b) {}
            public void onEvent(int t, Bundle b) {}
        });
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to SHADOW");
        recognizer.startListening(intent);
    }

    private void handleCommand(String raw) {
        String command = raw.toLowerCase(Locale.ROOT).trim();
        transcript.setText("YOU: " + raw);
        status.setText("COMMAND RECEIVED");
        if (command.contains("open ")) {
            String app = command.substring(command.indexOf("open ") + 5).trim();
            if (openApp(app)) speak("Opening " + app);
            else speak("I couldn't find that app.");
        } else if (command.startsWith("search ")) {
            String query = command.substring(7).trim();
            openWebSearch(query);
            speak("Searching the web for " + query);
        } else if (command.startsWith("search for ")) {
            String query = command.substring(11).trim();
            openWebSearch(query);
            speak("Searching the web for " + query);
        } else if (command.contains("what time")) {
            String time = new java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(new java.util.Date());
            speak("The time is " + time);
        } else if (command.contains("hello") || command.contains("hi shadow")) {
            speak("Hello chief. SHADOW is online.");
        } else {
            speak("I heard " + raw + ". I can open apps and search the web. More AI features can be added next.");
        }
    }

    private boolean openApp(String name) {
        String[] packages = {
            "youtube:com.google.android.youtube",
            "chrome:com.android.chrome",
            "whatsapp:com.whatsapp",
            "instagram:com.instagram.android",
            "settings:com.android.settings",
            "camera:com.android.camera2",
            "gmail:com.google.android.gm",
            "maps:com.google.android.apps.maps",
            "phone:com.google.android.dialer"
        };
        for (String item : packages) {
            String[] pair = item.split(":");
            if (name.contains(pair[0])) {
                Intent launch = getPackageManager().getLaunchIntentForPackage(pair[1]);
                if (launch != null) { startActivity(launch); return true; }
            }
        }
        Intent generic = getPackageManager().getLaunchIntentForPackage(name);
        if (generic != null) { startActivity(generic); return true; }
        return false;
    }

    private void openWebSearch(String query) {
        Intent search = new Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)));
        startActivity(search);
    }

    private void speak(String message) {
        transcript.setText(transcript.getText() + "\nSHADOW: " + message);
        if (tts != null) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "shadow_reply");
        status.setText("SYSTEM ONLINE  •  STANDBY");
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == MIC_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) startListening();
        else status.setText("MICROPHONE PERMISSION NEEDED");
    }

    @Override protected void onDestroy() {
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
